/**
 * App.jsx -- Main application shell
 *
 * Sets up:
 * 1. React Router with 5 routes (Dashboard, Compare, Fixtures, Recommendations, Wildcard)
 * 2. Persistent top navigation bar
 * 3. First-time setup screen (enter Team ID)
 * 4. Refresh Data button
 * 5. FplContext provider (wraps everything so all pages can access data)
 */

import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import { FplProvider, useFpl } from "./context/FplContext.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Compare from "./pages/Compare.jsx";
import Fixtures from "./pages/Fixtures.jsx";
import Recommendations from "./pages/Recommendations.jsx";
import Wildcard from "./pages/Wildcard.jsx";
import { formatDate } from "./utils/formatters.js";

export default function App() {
  return (
    <FplProvider>
      <BrowserRouter>
        <AppShell />
      </BrowserRouter>
    </FplProvider>
  );
}

// ---------------------------------------------------------------------------
// App Shell (needs to be inside FplProvider to use useFpl)
// ---------------------------------------------------------------------------

function AppShell() {
  const { teamId, setTeamId, loadData, loading, lastUpdated, error, currentGw } = useFpl();
  const [inputId, setInputId] = useState("");

  // On mount, if we already have a team ID, load data automatically
  useEffect(() => {
    if (teamId) {
      loadData();
    }
    // Run only once on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Handle first-time team ID submission.
   */
  const handleSetup = (e) => {
    e.preventDefault();
    const cleaned = inputId.trim();
    if (!cleaned) return;
    setTeamId(cleaned);
    // Load data after a tick so state has updated
    setTimeout(() => loadData(), 100);
  };

  /**
   * Handle "Refresh Data" click.
   */
  const handleRefresh = () => {
    loadData(true); // forceRefresh = true
  };

  // ----- First-time setup screen (no team ID yet) -----
  if (!teamId) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-md space-y-6 text-center">
          <h1 className="text-3xl font-bold">FPL Companion</h1>
          <p className="text-gray-400 text-sm">
            Enter your FPL Team ID to get started. You can find it in the URL
            when you view your team on the FPL website:
            <br />
            <span className="text-gray-500">
              fantasy.premierleague.com/entry/<strong className="text-white">YOUR_ID</strong>/event/...
            </span>
          </p>
          <form onSubmit={handleSetup} className="flex gap-2">
            <input
              type="text"
              value={inputId}
              onChange={(e) => setInputId(e.target.value)}
              placeholder="e.g. 1234567"
              className="flex-1 px-4 py-3 bg-[#111] border border-[#333] rounded-lg text-lg text-center focus:outline-none focus:border-[#555]"
              autoFocus
            />
            <button
              type="submit"
              className="px-6 py-3 bg-green-600 hover:bg-green-500 rounded-lg font-semibold transition-colors"
            >
              Save
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ----- Main app (team ID exists) -----
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation bar */}
      <nav className="sticky top-0 z-50 border-b border-[#222]" style={{ backgroundColor: "#0a0a0a" }}>
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
          {/* Left: nav links */}
          <div className="flex items-center gap-1 overflow-x-auto">
            <NavItem to="/" label="My Squad" />
            <NavItem to="/compare" label="Compare" />
            <NavItem to="/fixtures" label="Fixtures" />
            <NavItem to="/recommendations" label="Picks" />
            <NavItem to="/wildcard" label="Wildcard" />
          </div>

          {/* Right: info + actions */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Current GW indicator */}
            {currentGw && (
              <span className="text-xs text-gray-500 hidden md:inline">
                GW{currentGw}
              </span>
            )}

            {/* Last updated */}
            {lastUpdated && (
              <span className="text-[10px] text-gray-600 hidden lg:inline">
                Updated {formatDate(lastUpdated)}
              </span>
            )}

            {/* Refresh button */}
            <button
              onClick={handleRefresh}
              disabled={loading}
              className="px-3 py-1.5 bg-[#222] hover:bg-[#333] rounded-lg text-xs font-medium transition-colors disabled:opacity-50"
            >
              {loading ? "Loading..." : "Refresh"}
            </button>

            {/* Settings: change team ID */}
            <button
              onClick={() => {
                const newId = prompt("Enter new FPL Team ID:", teamId);
                if (newId && newId.trim() !== teamId) {
                  setTeamId(newId.trim());
                  setTimeout(() => loadData(true), 100);
                }
              }}
              className="text-gray-500 hover:text-gray-300 text-sm"
              title="Change Team ID"
            >
              ⚙
            </button>
          </div>
        </div>
      </nav>

      {/* Error banner */}
      {error && (
        <div className="bg-red-900/40 border-b border-red-800/50 px-4 py-2 text-sm text-red-300">
          {error}
          <button
            onClick={() => loadData(true)}
            className="ml-3 text-red-200 underline hover:text-white text-xs"
          >
            Retry
          </button>
        </div>
      )}

      {/* Page content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/compare" element={<Compare />} />
          <Route path="/fixtures" element={<Fixtures />} />
          <Route path="/recommendations" element={<Recommendations />} />
          <Route path="/wildcard" element={<Wildcard />} />
        </Routes>
      </main>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Nav link component
// ---------------------------------------------------------------------------

function NavItem({ to, label }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
          isActive
            ? "bg-[#1a1a2e] text-white"
            : "text-gray-400 hover:text-gray-200 hover:bg-[#111]"
        }`
      }
    >
      {label}
    </NavLink>
  );
}
