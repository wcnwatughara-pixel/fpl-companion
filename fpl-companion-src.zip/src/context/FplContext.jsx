/**
 * FplContext.jsx -- Global state management
 *
 * This is the app's central data store, built with React Context + useReducer.
 * It holds all FPL data (players, fixtures, user team, etc.) and provides
 * functions to load data, refresh it, and update settings.
 *
 * Any component in the app can access this data by calling useFpl().
 *
 * State shape:
 *   loading    - true while data is being fetched
 *   error      - error message if something went wrong
 *   teamId     - the user's FPL team ID
 *   players    - normalised array of all ~700 players
 *   teamsById  - lookup map: team ID -> team object
 *   currentGw  - the current/upcoming gameweek number
 *   events     - all gameweek objects (deadlines, averages, etc.)
 *   entry      - the user's team summary (rank, points, value)
 *   picks      - the user's current squad selection
 *   lastUpdated - timestamp of last data fetch
 */

import { createContext, useContext, useReducer, useCallback } from "react";
import { loadAllData, saveTeamId, getTeamId, getLastUpdated } from "../api/fplApi.js";
import { transformAll } from "../utils/transforms.js";
import { calculateCompositeScores } from "../utils/scoring.js";

// ---------------------------------------------------------------------------
// Context setup
// ---------------------------------------------------------------------------

const FplContext = createContext(null);

// ---------------------------------------------------------------------------
// Reducer (state machine)
// ---------------------------------------------------------------------------

/**
 * The reducer handles state transitions. Each action type describes
 * what happened, and the reducer returns the new state.
 */
const initialState = {
  loading: false,
  error: null,
  teamId: getTeamId(),
  players: [],
  teamsById: {},
  currentGw: null,
  events: [],
  elementTypes: [],
  gameSettings: null,
  entry: null,
  picks: null,
  lastUpdated: getLastUpdated(),
};

function fplReducer(state, action) {
  switch (action.type) {
    // Started fetching data
    case "LOADING":
      return { ...state, loading: true, error: null };

    // Data fetched and transformed successfully
    case "DATA_LOADED":
      return {
        ...state,
        loading: false,
        error: null,
        players: action.payload.players,
        teamsById: action.payload.teamsById,
        currentGw: action.payload.currentGw,
        events: action.payload.events,
        elementTypes: action.payload.elementTypes,
        gameSettings: action.payload.gameSettings,
        entry: action.payload.entry,
        picks: action.payload.picks,
        lastUpdated: new Date().toISOString(),
      };

    // Something went wrong during fetch
    case "ERROR":
      return { ...state, loading: false, error: action.payload };

    // User entered/changed their team ID
    case "SET_TEAM_ID":
      return { ...state, teamId: action.payload };

    default:
      return state;
  }
}

// ---------------------------------------------------------------------------
// Provider component
// ---------------------------------------------------------------------------

/**
 * FplProvider wraps the entire app and makes FPL data available
 * to all child components via the useFpl() hook.
 */
export function FplProvider({ children }) {
  const [state, dispatch] = useReducer(fplReducer, initialState);

  /**
   * Load all data from the FPL API.
   * This is the main "fetch everything" function.
   *
   * Steps:
   * 1. Fetch raw data from all endpoints (with caching)
   * 2. Transform/normalise the data (parse strings, map teams, etc.)
   * 3. Calculate composite scores for every player
   * 4. Store everything in state
   *
   * @param {boolean} forceRefresh - If true, skip cache and re-fetch
   */
  const loadData = useCallback(
    async (forceRefresh = false) => {
      const teamId = state.teamId;
      if (!teamId) {
        dispatch({ type: "ERROR", payload: "No team ID set. Enter your FPL team ID to get started." });
        return;
      }

      dispatch({ type: "LOADING" });

      try {
        // Step 1: Fetch raw data
        // We need to figure out the current GW first from bootstrap.
        // But loadAllData needs it too. So we do a two-pass:
        // first get bootstrap to find currentGw, then get picks for that GW.
        const raw = await loadAllData(teamId, 0, forceRefresh);

        // Step 2: Transform -- parse strings, build lookups, enrich players
        const transformed = transformAll(raw.bootstrap, raw.fixtures);

        // Now re-fetch picks for the actual current GW if needed
        let picks = raw.picks;
        if (!picks && transformed.currentGw >= 1) {
          // Try fetching picks for the latest completed GW
          const completedGw = transformed.currentGw - 1;
          if (completedGw >= 1) {
            try {
              const { fetchPicks } = await import("../api/fplApi.js");
              picks = await fetchPicks(teamId, completedGw, forceRefresh);
            } catch {
              // Picks not available -- that's fine
            }
          }
        }

        // Step 3: Calculate composite scores
        // Count completed gameweeks for the early-season discount
        const completedGws = transformed.events.filter((e) => e.finished).length;
        const scoredPlayers = calculateCompositeScores(
          transformed.players,
          completedGws
        );

        // Step 4: Dispatch everything to state
        dispatch({
          type: "DATA_LOADED",
          payload: {
            players: scoredPlayers,
            teamsById: transformed.teamsById,
            currentGw: transformed.currentGw,
            events: transformed.events,
            elementTypes: transformed.elementTypes,
            gameSettings: transformed.gameSettings,
            entry: raw.entry,
            picks,
          },
        });
      } catch (err) {
        dispatch({ type: "ERROR", payload: err.message });
      }
    },
    [state.teamId]
  );

  /**
   * Set the user's FPL team ID and save it to localStorage.
   * @param {string} id - The team ID
   */
  const setTeamId = useCallback((id) => {
    saveTeamId(id);
    dispatch({ type: "SET_TEAM_ID", payload: id });
  }, []);

  // Bundle everything into a single value object for the context
  const value = {
    ...state,
    loadData,
    setTeamId,
  };

  return <FplContext.Provider value={value}>{children}</FplContext.Provider>;
}

// ---------------------------------------------------------------------------
// Hook for consuming components
// ---------------------------------------------------------------------------

/**
 * Custom hook to access FPL data from any component.
 * Usage: const { players, loading, loadData } = useFpl();
 */
export function useFpl() {
  const context = useContext(FplContext);
  if (!context) {
    throw new Error("useFpl() must be used within an <FplProvider>");
  }
  return context;
}
