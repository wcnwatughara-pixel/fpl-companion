/**
 * ComparisonTable.jsx -- Side-by-side player comparison
 *
 * Takes 2-4 selected players and displays their stats in a table
 * where each column is a player. Makes it easy to compare players
 * at a glance. Used on the Compare page.
 */

import { formatPrice, formatDecimal, formatPercent } from "../utils/formatters.js";
import { FixtureMiniRow } from "./FixtureGrid.jsx";
import ScoreBar from "./ScoreBar.jsx";

/**
 * The rows we display in the comparison table.
 * Each row has a label and a function to extract the value from a player.
 */
const STAT_ROWS = [
  { label: "Position", getValue: (p) => p.position_name },
  { label: "Team", getValue: (p) => p.team_name },
  { label: "Price", getValue: (p) => `${formatPrice(p.price)}m` },
  { label: "Form", getValue: (p) => formatDecimal(p.form_num) },
  { label: "Total Points", getValue: (p) => p.total_points },
  { label: "Pts/90", getValue: (p) => formatDecimal(p.pts_per_90) },
  { label: "ICT Index", getValue: (p) => formatDecimal(p.ict_num) },
  { label: "xG", getValue: (p) => formatDecimal(p.xg) },
  { label: "xA", getValue: (p) => formatDecimal(p.xa) },
  { label: "xGI", getValue: (p) => formatDecimal(p.xgi) },
  { label: "xGI/90", getValue: (p) => formatDecimal(p.xgi_per_90) },
  { label: "Minutes", getValue: (p) => p.minutes },
  { label: "Ownership", getValue: (p) => formatPercent(p.ownership) },
  { label: "Status", getValue: (p) => p.status === "a" ? "Available" : p.news || "Unavailable" },
];

export default function ComparisonTable({ players, onRemovePlayer }) {
  if (!players || players.length === 0) {
    return (
      <p className="text-gray-500 text-sm text-center py-8">
        Search for players above to compare them side by side.
      </p>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr>
            <th className="text-left py-2 px-3 text-gray-400 text-xs font-medium w-28">
              Stat
            </th>
            {players.map((player) => (
              <th key={player.id} className="py-2 px-3 text-center min-w-[120px]">
                <div className="flex flex-col items-center gap-1">
                  <span className="font-semibold text-sm">{player.web_name}</span>
                  {/* Remove button */}
                  <button
                    onClick={() => onRemovePlayer?.(player.id)}
                    className="text-[10px] text-gray-500 hover:text-red-400 transition-colors"
                  >
                    Remove
                  </button>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {/* Stat rows */}
          {STAT_ROWS.map((row) => (
            <tr key={row.label} className="border-t border-[#1a1a1a]">
              <td className="py-2 px-3 text-gray-400 text-xs font-medium">
                {row.label}
              </td>
              {players.map((player) => {
                const val = row.getValue(player);
                // Highlight the best value in green (for numeric stats)
                const allVals = players.map((p) => row.getValue(p));
                const isBest =
                  typeof val === "number" &&
                  val === Math.max(...allVals.filter((v) => typeof v === "number"));

                return (
                  <td
                    key={player.id}
                    className="py-2 px-3 text-center tabular-nums text-xs"
                    style={{ color: isBest ? "#22c55e" : undefined }}
                  >
                    {val}
                  </td>
                );
              })}
            </tr>
          ))}

          {/* Composite score row */}
          <tr className="border-t border-[#1a1a1a]">
            <td className="py-2 px-3 text-gray-400 text-xs font-medium">
              Composite Score
            </td>
            {players.map((player) => (
              <td key={player.id} className="py-2 px-3">
                <ScoreBar score={player.compositeScore || 0} />
              </td>
            ))}
          </tr>

          {/* Upcoming fixtures row */}
          <tr className="border-t border-[#1a1a1a]">
            <td className="py-2 px-3 text-gray-400 text-xs font-medium">
              Next 5 Fixtures
            </td>
            {players.map((player) => (
              <td key={player.id} className="py-2 px-3">
                <FixtureMiniRow
                  fixtures={player.upcoming_fixtures?.slice(0, 5)}
                />
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
