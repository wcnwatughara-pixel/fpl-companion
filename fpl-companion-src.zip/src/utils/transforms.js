/**
 * transforms.js -- Data normalisation
 *
 * The FPL API returns many numeric values as strings (form, ict_index,
 * expected_goals, etc.). This module converts them to proper numbers
 * and attaches human-readable labels (position name, team name).
 *
 * It also builds per-player fixture lists so we know what games
 * each player has coming up in the next several gameweeks.
 */

// ---------------------------------------------------------------------------
// Position mapping
// ---------------------------------------------------------------------------

/**
 * Map the API's element_type number to a short position label.
 * 1 = Goalkeeper, 2 = Defender, 3 = Midfielder, 4 = Forward
 */
const POSITION_MAP = {
  1: "GKP",
  2: "DEF",
  3: "MID",
  4: "FWD",
};

// ---------------------------------------------------------------------------
// Player normalisation
// ---------------------------------------------------------------------------

/**
 * Take the raw player object from the API and add computed/normalised fields.
 *
 * @param {Object} rawPlayer - A single element from bootstrap.elements
 * @param {Object} teamsById - Lookup map: team ID -> team object
 * @param {Array} upcomingFixtures - Pre-built fixture list for this player's team
 * @returns {Object} - The player object with extra normalised fields added
 */
export function normalisePlayer(rawPlayer, teamsById, upcomingFixtures) {
  const team = teamsById[rawPlayer.team] || {};

  // Parse all the string-typed numeric fields into actual numbers
  const form_num = parseFloat(rawPlayer.form) || 0;
  const ict_num = parseFloat(rawPlayer.ict_index) || 0;
  const xg = parseFloat(rawPlayer.expected_goals) || 0;
  const xa = parseFloat(rawPlayer.expected_assists) || 0;
  const xgi = parseFloat(rawPlayer.expected_goal_involvements) || 0;
  const ownership = parseFloat(rawPlayer.selected_by_percent) || 0;
  const ppg = parseFloat(rawPlayer.points_per_game) || 0;

  // Calculate points per 90 minutes.
  // If the player has played fewer than 45 minutes total, we can't
  // get a meaningful per-90 figure, so default to 0.
  const minutes = rawPlayer.minutes || 0;
  const pts_per_90 = minutes >= 45
    ? (rawPlayer.total_points / (minutes / 90))
    : 0;

  // xGI per 90 -- use the API's own per-90 field if available,
  // otherwise compute it ourselves
  const xgi_per_90 = rawPlayer.expected_goal_involvements_per_90
    ?? (minutes >= 45 ? (xgi / (minutes / 90)) : 0);

  // Get the fixture list for this player's team
  const teamFixtures = upcomingFixtures[rawPlayer.team] || [];

  return {
    ...rawPlayer,
    // Normalised numbers
    price: rawPlayer.now_cost / 10,
    form_num,
    ict_num,
    xg,
    xa,
    xgi,
    xgi_per_90,
    pts_per_90,
    ppg,
    ownership,
    // Human-readable labels
    position_name: POSITION_MAP[rawPlayer.element_type] || "???",
    team_name: team.short_name || "???",
    team_full_name: team.name || "Unknown",
    // Upcoming fixtures for this player's team
    upcoming_fixtures: teamFixtures,
    upcoming_fdr: teamFixtures.map((f) => f.fdr),
  };
}

// ---------------------------------------------------------------------------
// Team lookup builder
// ---------------------------------------------------------------------------

/**
 * Build a lookup map from team ID to team object.
 * Makes it easy to go from a player's `team` field to the team's name.
 *
 * @param {Array} teams - The `teams` array from bootstrap-static
 * @returns {Object} - { [teamId]: teamObject }
 */
export function buildTeamsById(teams) {
  const map = {};
  for (const team of teams) {
    map[team.id] = team;
  }
  return map;
}

// ---------------------------------------------------------------------------
// Upcoming fixtures builder
// ---------------------------------------------------------------------------

/**
 * Build a map of upcoming fixtures per team.
 * For each of the 20 teams, produces an array of the next N gameweeks'
 * fixtures, each with opponent, home/away, and FDR rating.
 *
 * @param {Array} fixtures - The full fixtures array from the API
 * @param {Object} teamsById - Lookup map from buildTeamsById()
 * @param {number} currentGw - The current (or next upcoming) gameweek number
 * @param {number} lookAhead - How many future GWs to include (default 6)
 * @returns {Object} - { [teamId]: [{ gw, opponent, opponent_full, is_home, fdr }] }
 */
export function buildUpcomingFixtures(fixtures, teamsById, currentGw, lookAhead = 6) {
  const result = {};

  // Filter to only future gameweeks within our look-ahead window
  const futureFixtures = fixtures.filter((f) => {
    return f.event != null && f.event >= currentGw && f.event < currentGw + lookAhead;
  });

  for (const fixture of futureFixtures) {
    // For the HOME team, their opponent is the AWAY team
    if (!result[fixture.team_h]) result[fixture.team_h] = [];
    result[fixture.team_h].push({
      gw: fixture.event,
      opponent: teamsById[fixture.team_a]?.short_name || "???",
      opponent_full: teamsById[fixture.team_a]?.name || "Unknown",
      is_home: true,
      fdr: fixture.team_h_difficulty,
    });

    // For the AWAY team, their opponent is the HOME team
    if (!result[fixture.team_a]) result[fixture.team_a] = [];
    result[fixture.team_a].push({
      gw: fixture.event,
      opponent: teamsById[fixture.team_h]?.short_name || "???",
      opponent_full: teamsById[fixture.team_h]?.name || "Unknown",
      is_home: false,
      fdr: fixture.team_a_difficulty,
    });
  }

  // Sort each team's fixtures by gameweek number
  for (const teamId of Object.keys(result)) {
    result[teamId].sort((a, b) => a.gw - b.gw);
  }

  return result;
}

// ---------------------------------------------------------------------------
// Find current gameweek
// ---------------------------------------------------------------------------

/**
 * Determine the current gameweek number from the events array.
 * The API marks one event as `is_current` and one as `is_next`.
 * We want the "next" one if it exists (that's the upcoming deadline),
 * otherwise fall back to the current one.
 *
 * @param {Array} events - The `events` array from bootstrap-static
 * @returns {number} - The current or next gameweek number
 */
export function findCurrentGameweek(events) {
  // The "next" gameweek is the one with the upcoming deadline
  const nextGw = events.find((e) => e.is_next);
  if (nextGw) return nextGw.id;

  // If there's no "next" (end of season?), use "current"
  const currentGw = events.find((e) => e.is_current);
  if (currentGw) return currentGw.id;

  // Fallback: return the first unfinished gameweek
  const unfinished = events.find((e) => !e.finished);
  return unfinished ? unfinished.id : 1;
}

// ---------------------------------------------------------------------------
// Full transform pipeline
// ---------------------------------------------------------------------------

/**
 * Run the full data transformation pipeline.
 * Takes raw API responses and produces normalised, enriched player data
 * ready for the scoring algorithm and UI.
 *
 * @param {Object} bootstrap - The bootstrap-static response
 * @param {Array} fixtures - The fixtures response
 * @returns {Object} - { players, teamsById, currentGw, events, elementTypes }
 */
export function transformAll(bootstrap, fixtures) {
  const teamsById = buildTeamsById(bootstrap.teams);
  const currentGw = findCurrentGameweek(bootstrap.events);
  const upcomingFixtures = buildUpcomingFixtures(
    fixtures,
    teamsById,
    currentGw
  );

  const players = bootstrap.elements.map((rawPlayer) =>
    normalisePlayer(rawPlayer, teamsById, upcomingFixtures)
  );

  return {
    players,
    teamsById,
    currentGw,
    events: bootstrap.events,
    elementTypes: bootstrap.element_types,
    gameSettings: bootstrap.game_settings,
  };
}
