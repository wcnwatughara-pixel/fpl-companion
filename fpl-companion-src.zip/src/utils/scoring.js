/**
 * scoring.js -- Composite scoring algorithm
 *
 * This is the brain of the recommendation engine. It takes each player's
 * stats and fixtures and produces a single composite score from 0-100
 * that represents how good a pick they are right now.
 *
 * How it works:
 * 1. Group players by position (GKP, DEF, MID, FWD)
 * 2. For each group, normalise each metric to a 0-100 scale using
 *    min-max normalisation (best in group = 100, worst = 0)
 * 3. Apply early-season confidence discounts (form is noisy early on,
 *    fixtures are reliable regardless of when in the season)
 * 4. Combine the normalised metrics using weighted average
 *
 * Weights:
 *   Fixture difficulty: 30% (most reliable early-season signal)
 *   Points per 90:     20%
 *   ICT index:         15%
 *   xGI per 90:        15%
 *   Minutes played:    10%
 *   Form:              10%
 */

import { calcFixtureScore } from "./fdrCalc.js";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

/**
 * Weights for each scoring component. Must sum to 1.0.
 * These determine how much each factor contributes to the final score.
 */
const WEIGHTS = {
  fixtureDifficulty: 0.30,
  pointsPer90: 0.20,
  ictIndex: 0.15,
  xgiPer90: 0.15,
  minutesPlayed: 0.10,
  form: 0.10,
};

/**
 * Early-season confidence discounts.
 * In the first few gameweeks, stats are noisy because the sample size
 * is small. We discount volatile metrics and lean more on fixtures
 * (which are known in advance and therefore 100% reliable).
 *
 * A discount of 0.6 means we only trust that metric at 60% of its
 * normalised value. The "missing" weight effectively shifts toward
 * the undiscounted metrics (mainly fixtures).
 */
const EARLY_SEASON_DISCOUNTS = {
  fixtureDifficulty: 1.0, // Fixtures are known -- no discount
  pointsPer90: 0.7,       // Small sample makes this noisy
  ictIndex: 0.8,          // Slightly more stable than raw points
  xgiPer90: 0.8,          // Model-based, somewhat stable
  minutesPlayed: 0.9,     // Fairly reliable even with few games
  form: 0.6,              // Most volatile early on
};

/**
 * After this many completed gameweeks, stop applying discounts.
 * By GW10, there's enough data for all metrics to be meaningful.
 */
const EARLY_SEASON_THRESHOLD = 10;

// ---------------------------------------------------------------------------
// Normalisation
// ---------------------------------------------------------------------------

/**
 * Min-max normalisation: scale a value to 0-100 within a group.
 * The player with the highest value in the group gets 100.
 * The player with the lowest gets 0.
 *
 * If min === max (everyone has the same value), return 50 (neutral).
 *
 * @param {number} value - The raw value to normalise
 * @param {number} min - The minimum value in the group
 * @param {number} max - The maximum value in the group
 * @returns {number} - Normalised value from 0 to 100
 */
function minMaxNorm(value, min, max) {
  if (max === min) return 50;
  return ((value - min) / (max - min)) * 100;
}

// ---------------------------------------------------------------------------
// Nailedness (minutes played) scoring
// ---------------------------------------------------------------------------

/**
 * Calculate how "nailed on" a player is based on minutes played.
 * A player who has played every minute of every finished GW scores 100.
 *
 * @param {number} minutes - Total minutes played this season
 * @param {number} finishedGws - Number of completed gameweeks
 * @returns {number} - Nailedness score from 0 to 100
 */
function calcNailedness(minutes, finishedGws) {
  if (finishedGws <= 0) return 50; // Can't calculate before season starts
  const maxPossible = finishedGws * 90;
  return Math.min(100, (minutes / maxPossible) * 100);
}

// ---------------------------------------------------------------------------
// Main scoring function
// ---------------------------------------------------------------------------

/**
 * Calculate composite scores for ALL players.
 *
 * Players are grouped by position before normalisation, so a goalkeeper's
 * stats are compared to other goalkeepers (not to strikers who naturally
 * score more goals).
 *
 * @param {Array} players - Array of normalised player objects (from transforms.js)
 * @param {number} completedGws - How many gameweeks have finished
 * @returns {Array} - Same players array, but each player now has:
 *                     compositeScore (number), scoreBreakdown (object)
 */
export function calculateCompositeScores(players, completedGws) {
  // Determine if we should apply early-season discounts
  const isEarlySeason = completedGws < EARLY_SEASON_THRESHOLD;

  // Group players by position
  const groups = { 1: [], 2: [], 3: [], 4: [] };
  for (const player of players) {
    const posGroup = groups[player.element_type];
    if (posGroup) posGroup.push(player);
  }

  // Process each position group separately
  const scoredPlayers = [];

  for (const positionType of [1, 2, 3, 4]) {
    const group = groups[positionType];
    if (group.length === 0) continue;

    // Step 1: Calculate raw metric values for each player in the group
    const rawMetrics = group.map((player) => ({
      player,
      fixtureScore: calcFixtureScore(player.upcoming_fdr, 5),
      ptsPer90: player.pts_per_90,
      ict: player.ict_num,
      xgiPer90: player.xgi_per_90,
      nailedness: calcNailedness(player.minutes, completedGws),
      form: player.form_num,
    }));

    // Step 2: Find min and max for each metric within the group
    const ranges = {
      fixtureScore: getRange(rawMetrics, "fixtureScore"),
      ptsPer90: getRange(rawMetrics, "ptsPer90"),
      ict: getRange(rawMetrics, "ict"),
      xgiPer90: getRange(rawMetrics, "xgiPer90"),
      nailedness: getRange(rawMetrics, "nailedness"),
      form: getRange(rawMetrics, "form"),
    };

    // Step 3: Normalise and score each player
    for (const { player, fixtureScore, ptsPer90, ict, xgiPer90, nailedness, form } of rawMetrics) {
      // Normalise each metric to 0-100 within the position group
      const normFixture = minMaxNorm(fixtureScore, ranges.fixtureScore.min, ranges.fixtureScore.max);
      const normPts = minMaxNorm(ptsPer90, ranges.ptsPer90.min, ranges.ptsPer90.max);
      const normIct = minMaxNorm(ict, ranges.ict.min, ranges.ict.max);
      const normXgi = minMaxNorm(xgiPer90, ranges.xgiPer90.min, ranges.xgiPer90.max);
      const normMinutes = minMaxNorm(nailedness, ranges.nailedness.min, ranges.nailedness.max);
      const normForm = minMaxNorm(form, ranges.form.min, ranges.form.max);

      // Apply early-season discounts if applicable
      const discountedFixture = normFixture * (isEarlySeason ? EARLY_SEASON_DISCOUNTS.fixtureDifficulty : 1);
      const discountedPts = normPts * (isEarlySeason ? EARLY_SEASON_DISCOUNTS.pointsPer90 : 1);
      const discountedIct = normIct * (isEarlySeason ? EARLY_SEASON_DISCOUNTS.ictIndex : 1);
      const discountedXgi = normXgi * (isEarlySeason ? EARLY_SEASON_DISCOUNTS.xgiPer90 : 1);
      const discountedMinutes = normMinutes * (isEarlySeason ? EARLY_SEASON_DISCOUNTS.minutesPlayed : 1);
      const discountedForm = normForm * (isEarlySeason ? EARLY_SEASON_DISCOUNTS.form : 1);

      // Weighted sum
      const compositeScore =
        discountedFixture * WEIGHTS.fixtureDifficulty +
        discountedPts * WEIGHTS.pointsPer90 +
        discountedIct * WEIGHTS.ictIndex +
        discountedXgi * WEIGHTS.xgiPer90 +
        discountedMinutes * WEIGHTS.minutesPlayed +
        discountedForm * WEIGHTS.form;

      // Store the breakdown so the UI can show WHY a player scored high/low
      const scoreBreakdown = {
        fixtureDifficulty: Math.round(discountedFixture * 10) / 10,
        pointsPer90: Math.round(discountedPts * 10) / 10,
        ictIndex: Math.round(discountedIct * 10) / 10,
        xgiPer90: Math.round(discountedXgi * 10) / 10,
        minutesPlayed: Math.round(discountedMinutes * 10) / 10,
        form: Math.round(discountedForm * 10) / 10,
      };

      scoredPlayers.push({
        ...player,
        compositeScore: Math.round(compositeScore * 10) / 10,
        scoreBreakdown,
      });
    }
  }

  // Sort by composite score (highest first) for convenience
  scoredPlayers.sort((a, b) => b.compositeScore - a.compositeScore);

  return scoredPlayers;
}

// ---------------------------------------------------------------------------
// Captaincy scoring (single-gameweek focus)
// ---------------------------------------------------------------------------

/**
 * Calculate a single-GW captaincy score for each player.
 * This weights the next fixture difficulty and form more heavily
 * than the standard composite score, because we only care about
 * the next game (not the next 5 weeks).
 *
 * Weights for captaincy:
 *   Next fixture FDR: 35%
 *   Form: 25%
 *   xGI per 90: 20%
 *   ICT: 10%
 *   Points per 90: 10%
 *
 * @param {Array} players - Normalised player array
 * @returns {Array} - Players sorted by captaincy score (highest first)
 */
export function calculateCaptaincyScores(players) {
  // Only consider players who actually play (decent minutes)
  const eligible = players.filter((p) => p.minutes >= 90);

  const scored = eligible.map((player) => {
    // For captaincy, we only care about the NEXT fixture (not 5)
    const nextFdr = player.upcoming_fdr?.[0] ?? 3;
    const fdrScore = ((5 - nextFdr) / 4) * 100;

    const captaincyScore =
      fdrScore * 0.35 +
      (player.form_num / 10) * 100 * 0.25 + // form is typically 0-10ish
      Math.min(100, player.xgi_per_90 * 20) * 0.20 + // scale up to ~100
      Math.min(100, player.ict_num / 5) * 0.10 +
      Math.min(100, player.pts_per_90 * 10) * 0.10;

    return {
      ...player,
      captaincyScore: Math.round(captaincyScore * 10) / 10,
      nextFixture: player.upcoming_fixtures?.[0] || null,
    };
  });

  scored.sort((a, b) => b.captaincyScore - a.captaincyScore);
  return scored;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Find the min and max values for a given metric across a group of players.
 */
function getRange(items, key) {
  let min = Infinity;
  let max = -Infinity;
  for (const item of items) {
    if (item[key] < min) min = item[key];
    if (item[key] > max) max = item[key];
  }
  return { min, max };
}
