/**
 * Dashboard.jsx -- My Squad view (home page)
 *
 * Shows the user's current 15-man squad with key stats.
 * Top summary bar shows total points, rank, squad value, bank.
 * Each player appears as a PlayerCard.
 * Click a player to jump to Compare with that player pre-selected.
 */

import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useFpl } from "../context/FplContext.jsx";
import PlayerCard from "../components/PlayerCard.jsx";
import { formatNumber, formatPrice } from "../utils/formatters.js";

export default function Dashboard() {
  const { players, entry, picks, loading, error } = useFpl();
  const navigate = useNavigate();

  // Build the squad: match picks to full player data
  const squad = useMemo(() => {
    if (!picks?.picks || !players.length) return [];

    return picks.picks
      .map((pick) => {
        const player = players.find((p) => p.id === pick.element);
        if (!player) return null;
        return {
          ...player,
          squadPosition: pick.position, // 1-11 = starting, 12-15 = bench
          isCaptain: pick.is_captain,
          isViceCaptain: pick.is_vice_captain,
        };
      })
      .filter(Boolean)
      .sort((a, b) => a.squadPosition - b.squadPosition);
  }, [picks, players]);

  // Separate starting XI from bench
  const startingXI = squad.filter((p) => p.squadPosition <= 11);
  const bench = squad.filter((p) => p.squadPosition > 11);

  /**
   * When a player card is clicked, navigate to Compare
   * with that player's ID in the URL so it's pre-selected.
   */
  const handlePlayerClick = (player) => {
    navigate(`/compare?player=${player.id}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading squad data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-red-400">{error}</div>
      </div>
    );
  }

  if (!picks) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">
          No squad data found. Make sure your Team ID is correct and at least one gameweek has been played.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary bar */}
      {entry && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <SummaryCard label="Total Points" value={formatNumber(entry.summary_overall_points)} />
          <SummaryCard label="Overall Rank" value={formatNumber(entry.summary_overall_rank)} />
          <SummaryCard label="GW Points" value={formatNumber(entry.summary_event_points)} />
          <SummaryCard label="Squad Value" value={`${formatPrice(entry.last_deadline_value / 10)}m`} />
          <SummaryCard label="Bank" value={`${formatPrice(entry.last_deadline_bank / 10)}m`} />
        </div>
      )}

      {/* Team name */}
      {entry && (
        <h2 className="text-lg font-semibold text-gray-300">
          {entry.name}
          <span className="text-sm text-gray-500 ml-2">
            {entry.player_first_name} {entry.player_last_name}
          </span>
        </h2>
      )}

      {/* Starting XI */}
      <div>
        <h3 className="text-sm font-medium text-gray-400 mb-3">Starting XI</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {startingXI.map((player) => (
            <div key={player.id} className="relative">
              {/* Captain / vice badge */}
              {(player.isCaptain || player.isViceCaptain) && (
                <div className="absolute -top-1 -right-1 z-10 w-5 h-5 rounded-full bg-yellow-500 text-black text-[10px] font-bold flex items-center justify-center">
                  {player.isCaptain ? "C" : "V"}
                </div>
              )}
              <PlayerCard player={player} onClick={handlePlayerClick} />
            </div>
          ))}
        </div>
      </div>

      {/* Bench */}
      {bench.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-gray-400 mb-3">Bench</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {bench.map((player) => (
              <div key={player.id} className="opacity-70">
                <PlayerCard player={player} onClick={handlePlayerClick} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Small summary statistic card for the top bar.
 */
function SummaryCard({ label, value }) {
  return (
    <div className="rounded-lg p-3" style={{ backgroundColor: "#111111", border: "1px solid #222" }}>
      <div className="text-[10px] text-gray-500 uppercase tracking-wide">{label}</div>
      <div className="text-lg font-bold tabular-nums mt-0.5">{value}</div>
    </div>
  );
}
