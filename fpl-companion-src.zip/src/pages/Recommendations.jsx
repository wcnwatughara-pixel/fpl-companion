/**
 * Recommendations.jsx -- Transfer & Captaincy Recommendations
 *
 * Two tabs:
 * 1. Transfers: "Best Players In" (top picks not in squad) and
 *    "Consider Selling" (squad players with low scores)
 * 2. Captaincy: Top 10 captain picks for the upcoming GW
 *
 * Everything is driven by the composite scoring algorithm.
 */

import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useFpl } from "../context/FplContext.jsx";
import { calculateCaptaincyScores } from "../utils/scoring.js";
import { FixtureMiniRow } from "../components/FixtureGrid.jsx";
import ScoreBar from "../components/ScoreBar.jsx";
import { formatPrice, formatDecimal } from "../utils/formatters.js";

export default function Recommendations() {
  const { players, picks, loading } = useFpl();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState("transfers"); // "transfers" or "captaincy"
  const [positionFilter, setPositionFilter] = useState("All");
  const [maxPriceFilter, setMaxPriceFilter] = useState(15);

  // IDs of players in the user's current squad
  const squadIds = useMemo(() => {
    if (!picks?.picks) return new Set();
    return new Set(picks.picks.map((p) => p.element));
  }, [picks]);

  // "Best Players In": top players NOT in squad, sorted by composite score
  const bestIn = useMemo(() => {
    return players
      .filter((p) => !squadIds.has(p.id))
      .filter((p) => positionFilter === "All" || p.position_name === positionFilter)
      .filter((p) => p.price <= maxPriceFilter)
      .filter((p) => p.minutes >= 45) // only players who actually play
      .sort((a, b) => b.compositeScore - a.compositeScore)
      .slice(0, 20);
  }, [players, squadIds, positionFilter, maxPriceFilter]);

  // "Consider Selling": squad players with low composite scores
  const considerSelling = useMemo(() => {
    return players
      .filter((p) => squadIds.has(p.id))
      .sort((a, b) => a.compositeScore - b.compositeScore)
      .slice(0, 5);
  }, [players, squadIds]);

  // Captaincy picks
  const captainPicks = useMemo(() => {
    // Only rank players who are in the user's squad
    const squadPlayers = players.filter((p) => squadIds.has(p.id));
    return calculateCaptaincyScores(squadPlayers).slice(0, 10);
  }, [players, squadIds]);

  /**
   * Navigate to Compare page with two players pre-selected
   * (a recommended player vs. a current squad player).
   */
  const handleCompare = (playerId) => {
    navigate(`/compare?player=${playerId}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading recommendations...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Recommendations</h1>

      {/* Tab switcher */}
      <div className="flex gap-2">
        <button
          onClick={() => setActiveTab("transfers")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            activeTab === "transfers"
              ? "bg-[#333] text-white"
              : "bg-[#111] text-gray-400 hover:bg-[#1a1a1a]"
          }`}
        >
          Transfers
        </button>
        <button
          onClick={() => setActiveTab("captaincy")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            activeTab === "captaincy"
              ? "bg-[#333] text-white"
              : "bg-[#111] text-gray-400 hover:bg-[#1a1a1a]"
          }`}
        >
          Captaincy
        </button>
      </div>

      {/* Transfers tab */}
      {activeTab === "transfers" && (
        <div className="space-y-6">
          {/* Filters */}
          <div className="flex gap-3 items-end">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Position</label>
              <select
                value={positionFilter}
                onChange={(e) => setPositionFilter(e.target.value)}
                className="px-3 py-2 bg-[#111] border border-[#333] rounded-lg text-sm"
              >
                <option value="All">All</option>
                <option value="GKP">GKP</option>
                <option value="DEF">DEF</option>
                <option value="MID">MID</option>
                <option value="FWD">FWD</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">
                Max Price: {maxPriceFilter.toFixed(1)}m
              </label>
              <input
                type="range"
                min="3.5"
                max="15"
                step="0.5"
                value={maxPriceFilter}
                onChange={(e) => setMaxPriceFilter(parseFloat(e.target.value))}
                className="w-32"
              />
            </div>
          </div>

          {/* Best Players In */}
          <div>
            <h2 className="text-sm font-semibold text-gray-300 mb-3">Best Players to Buy</h2>
            <div className="rounded-lg overflow-hidden" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-xs text-gray-400">
                    <th className="text-left py-2 px-3">#</th>
                    <th className="text-left py-2 px-3">Player</th>
                    <th className="text-left py-2 px-3 hidden md:table-cell">Team</th>
                    <th className="text-center py-2 px-3">Pos</th>
                    <th className="text-right py-2 px-3">Price</th>
                    <th className="py-2 px-3 min-w-[120px]">Score</th>
                    <th className="py-2 px-3 hidden lg:table-cell">Next 5</th>
                    <th className="py-2 px-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {bestIn.map((player, i) => (
                    <tr key={player.id} className="border-t border-[#1a1a1a] hover:bg-[#1a1a1a]">
                      <td className="py-2 px-3 text-gray-500 tabular-nums">{i + 1}</td>
                      <td className="py-2 px-3 font-medium">{player.web_name}</td>
                      <td className="py-2 px-3 text-gray-400 hidden md:table-cell">{player.team_name}</td>
                      <td className="py-2 px-3 text-center">
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded" style={{
                          backgroundColor:
                            player.position_name === "GKP" ? "#f59e0b" :
                            player.position_name === "DEF" ? "#22c55e" :
                            player.position_name === "MID" ? "#3b82f6" : "#ef4444",
                          color: "#000",
                        }}>
                          {player.position_name}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right tabular-nums">{formatPrice(player.price)}m</td>
                      <td className="py-2 px-3">
                        <ScoreBar score={player.compositeScore || 0} />
                      </td>
                      <td className="py-2 px-3 hidden lg:table-cell">
                        <FixtureMiniRow fixtures={player.upcoming_fixtures?.slice(0, 5)} />
                      </td>
                      <td className="py-2 px-3">
                        <button
                          onClick={() => handleCompare(player.id)}
                          className="text-[10px] text-blue-400 hover:text-blue-300"
                        >
                          Compare
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Consider Selling */}
          {considerSelling.length > 0 && (
            <div>
              <h2 className="text-sm font-semibold text-gray-300 mb-3">Consider Selling</h2>
              <div className="rounded-lg overflow-hidden" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-gray-400">
                      <th className="text-left py-2 px-3">Player</th>
                      <th className="text-left py-2 px-3 hidden md:table-cell">Team</th>
                      <th className="text-center py-2 px-3">Pos</th>
                      <th className="text-right py-2 px-3">Price</th>
                      <th className="py-2 px-3 min-w-[120px]">Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {considerSelling.map((player) => (
                      <tr key={player.id} className="border-t border-[#1a1a1a]">
                        <td className="py-2 px-3 font-medium">{player.web_name}</td>
                        <td className="py-2 px-3 text-gray-400 hidden md:table-cell">{player.team_name}</td>
                        <td className="py-2 px-3 text-center text-xs">{player.position_name}</td>
                        <td className="py-2 px-3 text-right tabular-nums">{formatPrice(player.price)}m</td>
                        <td className="py-2 px-3">
                          <ScoreBar score={player.compositeScore || 0} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Captaincy tab */}
      {activeTab === "captaincy" && (
        <div>
          <h2 className="text-sm font-semibold text-gray-300 mb-3">Top Captain Picks</h2>
          <div className="rounded-lg overflow-hidden" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-400">
                  <th className="text-left py-2 px-3">#</th>
                  <th className="text-left py-2 px-3">Player</th>
                  <th className="text-left py-2 px-3 hidden md:table-cell">Team</th>
                  <th className="text-center py-2 px-3">Next Fixture</th>
                  <th className="text-right py-2 px-3">Form</th>
                  <th className="text-right py-2 px-3">xGI/90</th>
                  <th className="py-2 px-3 min-w-[100px]">Cap Score</th>
                </tr>
              </thead>
              <tbody>
                {captainPicks.map((player, i) => (
                  <tr key={player.id} className="border-t border-[#1a1a1a]">
                    <td className="py-2 px-3 text-gray-500 tabular-nums">{i + 1}</td>
                    <td className="py-2 px-3 font-medium">{player.web_name}</td>
                    <td className="py-2 px-3 text-gray-400 hidden md:table-cell">{player.team_name}</td>
                    <td className="py-2 px-3 text-center">
                      {player.nextFixture && (
                        <FixtureMiniRow fixtures={[player.nextFixture]} />
                      )}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums">{formatDecimal(player.form_num)}</td>
                    <td className="py-2 px-3 text-right tabular-nums">{formatDecimal(player.xgi_per_90)}</td>
                    <td className="py-2 px-3">
                      <ScoreBar score={player.captaincyScore || 0} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
