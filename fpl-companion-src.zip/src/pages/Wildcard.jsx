/**
 * Wildcard.jsx -- Wildcard Planner ("What If" Simulator)
 *
 * The core feature for Wesley's GW6 wildcard. Shows:
 * - LEFT column: Current squad (read-only reference)
 * - RIGHT column: Wildcard squad (editable)
 *
 * Features:
 * - Lock players you want to keep
 * - Remove unlocked players and search for replacements
 * - Auto-fill: algorithm picks the best available players within budget
 * - Budget tracking with rule validation (position limits, team limits)
 * - Score comparison: current squad vs. wildcard squad projected over 5 GWs
 */

import { useState, useMemo, useCallback } from "react";
import { useFpl } from "../context/FplContext.jsx";
import ScoreBar from "../components/ScoreBar.jsx";
import { FixtureMiniRow } from "../components/FixtureGrid.jsx";
import { formatPrice, formatDecimal } from "../utils/formatters.js";

// FPL squad rules
const POSITION_LIMITS = { GKP: 2, DEF: 5, MID: 5, FWD: 3 };
const MAX_PER_TEAM = 3;
const SQUAD_SIZE = 15;

export default function Wildcard() {
  const { players, picks, entry, loading } = useFpl();

  // The wildcard squad: array of { playerId, locked }
  const [wcSquad, setWcSquad] = useState([]);
  const [initialized, setInitialized] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [posFilter, setPosFilter] = useState("All");
  const [showSearch, setShowSearch] = useState(false);

  // Total budget = squad value + bank (both from the entry endpoint)
  const totalBudget = useMemo(() => {
    if (!entry) return 100;
    return (entry.last_deadline_value + entry.last_deadline_bank) / 10;
  }, [entry]);

  // Initialize wildcard squad from current picks (once)
  if (!initialized && picks?.picks && players.length > 0) {
    const initial = picks.picks.map((pick) => ({
      playerId: pick.element,
      locked: false,
    }));
    setWcSquad(initial);
    setInitialized(true);
  }

  // Current squad player objects (from picks)
  const currentSquad = useMemo(() => {
    if (!picks?.picks || !players.length) return [];
    return picks.picks
      .map((pick) => players.find((p) => p.id === pick.element))
      .filter(Boolean);
  }, [picks, players]);

  // Wildcard squad player objects (enriched)
  const wcPlayers = useMemo(() => {
    return wcSquad
      .map((slot) => {
        const player = players.find((p) => p.id === slot.playerId);
        if (!player) return null;
        return { ...player, locked: slot.locked };
      })
      .filter(Boolean);
  }, [wcSquad, players]);

  // Budget calculations
  const spent = useMemo(() => {
    return wcPlayers.reduce((sum, p) => sum + p.price, 0);
  }, [wcPlayers]);
  const remaining = totalBudget - spent;

  // Validation
  const validationErrors = useMemo(() => {
    const errors = [];

    // Check position counts
    const posCounts = { GKP: 0, DEF: 0, MID: 0, FWD: 0 };
    const teamCounts = {};

    for (const player of wcPlayers) {
      posCounts[player.position_name] = (posCounts[player.position_name] || 0) + 1;
      teamCounts[player.team] = (teamCounts[player.team] || 0) + 1;
    }

    for (const [pos, limit] of Object.entries(POSITION_LIMITS)) {
      if (posCounts[pos] > limit) {
        errors.push(`Too many ${pos} players (${posCounts[pos]}, max ${limit})`);
      }
    }

    // Check team limits
    for (const [teamId, count] of Object.entries(teamCounts)) {
      if (count > MAX_PER_TEAM) {
        const player = wcPlayers.find((p) => p.team === parseInt(teamId));
        errors.push(
          `Too many ${player?.team_full_name || "team"} players (${count}, max ${MAX_PER_TEAM})`
        );
      }
    }

    // Budget check
    if (remaining < 0) {
      errors.push(`Over budget by ${formatPrice(Math.abs(remaining))}m`);
    }

    return errors;
  }, [wcPlayers, remaining]);

  // Position counts for the current wildcard squad
  const posCounts = useMemo(() => {
    const counts = { GKP: 0, DEF: 0, MID: 0, FWD: 0 };
    for (const p of wcPlayers) {
      counts[p.position_name] = (counts[p.position_name] || 0) + 1;
    }
    return counts;
  }, [wcPlayers]);

  // Projected scores
  const currentSquadScore = useMemo(() => {
    return currentSquad.reduce((sum, p) => sum + (p.compositeScore || 0), 0);
  }, [currentSquad]);

  const wcSquadScore = useMemo(() => {
    return wcPlayers.reduce((sum, p) => sum + (p.compositeScore || 0), 0);
  }, [wcPlayers]);

  // Search results (players not already in wildcard squad)
  const searchResults = useMemo(() => {
    const wcIds = new Set(wcSquad.map((s) => s.playerId));
    return players
      .filter((p) => !wcIds.has(p.id))
      .filter((p) => p.minutes >= 45)
      .filter((p) => posFilter === "All" || p.position_name === posFilter)
      .filter((p) => {
        if (!searchQuery) return true;
        return p.web_name.toLowerCase().includes(searchQuery.toLowerCase());
      })
      .filter((p) => p.price <= remaining + 0.1) // can afford (small tolerance)
      .sort((a, b) => b.compositeScore - a.compositeScore)
      .slice(0, 15);
  }, [players, wcSquad, searchQuery, posFilter, remaining]);

  // ---------------------------------------------------------------------------
  // Actions
  // ---------------------------------------------------------------------------

  /** Toggle lock on a player in the wildcard squad */
  const toggleLock = useCallback((playerId) => {
    setWcSquad((prev) =>
      prev.map((s) =>
        s.playerId === playerId ? { ...s, locked: !s.locked } : s
      )
    );
  }, []);

  /** Remove a player from the wildcard squad (only if not locked) */
  const removePlayer = useCallback((playerId) => {
    setWcSquad((prev) => prev.filter((s) => s.playerId !== playerId));
  }, []);

  /** Add a player to the wildcard squad */
  const addPlayer = useCallback(
    (playerId) => {
      if (wcSquad.length >= SQUAD_SIZE) return;
      if (wcSquad.some((s) => s.playerId === playerId)) return;
      setWcSquad((prev) => [...prev, { playerId, locked: false }]);
      setSearchQuery("");
      setShowSearch(false);
    },
    [wcSquad]
  );

  /** Reset wildcard squad to current squad */
  const resetSquad = useCallback(() => {
    if (!picks?.picks) return;
    setWcSquad(picks.picks.map((pick) => ({ playerId: pick.element, locked: false })));
  }, [picks]);

  /** Auto-fill: fill empty slots with the best available players */
  const autoFill = useCallback(() => {
    const wcIds = new Set(wcSquad.map((s) => s.playerId));
    const currentPosCounts = { GKP: 0, DEF: 0, MID: 0, FWD: 0 };
    const currentTeamCounts = {};

    // Count what we already have
    for (const slot of wcSquad) {
      const p = players.find((pl) => pl.id === slot.playerId);
      if (p) {
        currentPosCounts[p.position_name] = (currentPosCounts[p.position_name] || 0) + 1;
        currentTeamCounts[p.team] = (currentTeamCounts[p.team] || 0) + 1;
      }
    }

    // Sort all available players by composite score
    const available = players
      .filter((p) => !wcIds.has(p.id))
      .filter((p) => p.minutes >= 45)
      .sort((a, b) => b.compositeScore - a.compositeScore);

    let budgetLeft = totalBudget - wcPlayers.reduce((s, p) => s + p.price, 0);
    const newSlots = [...wcSquad];

    for (const candidate of available) {
      if (newSlots.length >= SQUAD_SIZE) break;
      if (candidate.price > budgetLeft) continue;

      // Check position limit
      const pos = candidate.position_name;
      if ((currentPosCounts[pos] || 0) >= POSITION_LIMITS[pos]) continue;

      // Check team limit
      if ((currentTeamCounts[candidate.team] || 0) >= MAX_PER_TEAM) continue;

      // Add the player
      newSlots.push({ playerId: candidate.id, locked: false });
      currentPosCounts[pos] = (currentPosCounts[pos] || 0) + 1;
      currentTeamCounts[candidate.team] = (currentTeamCounts[candidate.team] || 0) + 1;
      budgetLeft -= candidate.price;
    }

    setWcSquad(newSlots);
  }, [wcSquad, players, totalBudget, wcPlayers]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading wildcard planner...</div>
      </div>
    );
  }

  if (!picks) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">
          Squad data needed. Make sure your Team ID is set and data is loaded.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Wildcard Planner</h1>

      {/* Budget bar */}
      <div className="rounded-lg p-4" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-400">Budget</span>
          <span className="text-sm font-semibold tabular-nums">
            {formatPrice(spent)}m / {formatPrice(totalBudget)}m
            <span className={`ml-2 ${remaining >= 0 ? "text-green-400" : "text-red-400"}`}>
              ({remaining >= 0 ? "+" : ""}{formatPrice(remaining)}m)
            </span>
          </span>
        </div>
        <div className="h-2 rounded-full bg-[#1a1a1a] overflow-hidden">
          <div
            className="h-full rounded-full transition-all"
            style={{
              width: `${Math.min(100, (spent / totalBudget) * 100)}%`,
              backgroundColor: remaining >= 0 ? "#22c55e" : "#ef4444",
            }}
          />
        </div>
        {/* Position counts */}
        <div className="flex gap-4 mt-2 text-xs text-gray-400">
          {Object.entries(POSITION_LIMITS).map(([pos, limit]) => (
            <span
              key={pos}
              className={posCounts[pos] > limit ? "text-red-400" : ""}
            >
              {pos}: {posCounts[pos] || 0}/{limit}
            </span>
          ))}
          <span>Total: {wcSquad.length}/{SQUAD_SIZE}</span>
        </div>
      </div>

      {/* Validation errors */}
      {validationErrors.length > 0 && (
        <div className="rounded-lg p-3 bg-red-900/30 border border-red-800/50">
          {validationErrors.map((err, i) => (
            <p key={i} className="text-xs text-red-400">{err}</p>
          ))}
        </div>
      )}

      {/* Action buttons */}
      <div className="flex gap-2">
        <button
          onClick={() => setShowSearch(!showSearch)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-sm font-medium transition-colors"
          disabled={wcSquad.length >= SQUAD_SIZE}
        >
          + Add Player
        </button>
        <button
          onClick={autoFill}
          className="px-4 py-2 bg-green-700 hover:bg-green-600 rounded-lg text-sm font-medium transition-colors"
          disabled={wcSquad.length >= SQUAD_SIZE}
        >
          Auto-Fill
        </button>
        <button
          onClick={resetSquad}
          className="px-4 py-2 bg-[#222] hover:bg-[#333] rounded-lg text-sm font-medium transition-colors"
        >
          Reset
        </button>
      </div>

      {/* Player search panel */}
      {showSearch && (
        <div className="rounded-lg p-4" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
          <div className="flex gap-3 mb-3">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for a player..."
              className="flex-1 px-3 py-2 bg-[#0a0a0a] border border-[#333] rounded-lg text-sm focus:outline-none"
            />
            <select
              value={posFilter}
              onChange={(e) => setPosFilter(e.target.value)}
              className="px-3 py-2 bg-[#0a0a0a] border border-[#333] rounded-lg text-sm"
            >
              <option value="All">All</option>
              <option value="GKP">GKP</option>
              <option value="DEF">DEF</option>
              <option value="MID">MID</option>
              <option value="FWD">FWD</option>
            </select>
          </div>
          <div className="max-h-48 overflow-y-auto space-y-1">
            {searchResults.map((player) => (
              <div
                key={player.id}
                onClick={() => addPlayer(player.id)}
                className="flex items-center justify-between px-3 py-2 rounded hover:bg-[#1a1a1a] cursor-pointer"
              >
                <div>
                  <span className="text-sm font-medium">{player.web_name}</span>
                  <span className="text-xs text-gray-500 ml-2">
                    {player.team_name} | {player.position_name}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs tabular-nums text-gray-400">
                    {formatPrice(player.price)}m
                  </span>
                  <span className="text-xs tabular-nums text-green-400">
                    {formatDecimal(player.compositeScore)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Squad comparison: two columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* LEFT: Current squad (reference) */}
        <div>
          <h2 className="text-sm font-semibold text-gray-400 mb-3">Current Squad</h2>
          <div className="space-y-1">
            {currentSquad.map((player) => (
              <SquadRow key={player.id} player={player} readonly />
            ))}
          </div>
        </div>

        {/* RIGHT: Wildcard squad (editable) */}
        <div>
          <h2 className="text-sm font-semibold text-gray-400 mb-3">Wildcard Squad</h2>
          <div className="space-y-1">
            {wcPlayers.map((player) => (
              <SquadRow
                key={player.id}
                player={player}
                locked={player.locked}
                onToggleLock={() => toggleLock(player.id)}
                onRemove={() => removePlayer(player.id)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Score comparison */}
      <div className="rounded-lg p-4" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
        <h3 className="text-sm font-semibold text-gray-300 mb-3">
          Projected Score Comparison (5 GW Composite)
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-gray-400 mb-1">Current Squad</div>
            <div className="text-2xl font-bold tabular-nums">{currentSquadScore.toFixed(1)}</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 mb-1">Wildcard Squad</div>
            <div
              className="text-2xl font-bold tabular-nums"
              style={{
                color: wcSquadScore > currentSquadScore ? "#22c55e" :
                       wcSquadScore < currentSquadScore ? "#ef4444" : "#fafafa",
              }}
            >
              {wcSquadScore.toFixed(1)}
              {wcSquadScore !== currentSquadScore && (
                <span className="text-sm ml-2">
                  ({wcSquadScore > currentSquadScore ? "+" : ""}
                  {(wcSquadScore - currentSquadScore).toFixed(1)})
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Squad row component (used in both columns)
// ---------------------------------------------------------------------------

function SquadRow({ player, readonly, locked, onToggleLock, onRemove }) {
  return (
    <div
      className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm"
      style={{ backgroundColor: "#111", border: "1px solid #1a1a1a" }}
    >
      {/* Position badge */}
      <span
        className="text-[9px] font-bold px-1 py-0.5 rounded min-w-[2rem] text-center"
        style={{
          backgroundColor:
            player.position_name === "GKP" ? "#f59e0b" :
            player.position_name === "DEF" ? "#22c55e" :
            player.position_name === "MID" ? "#3b82f6" : "#ef4444",
          color: "#000",
        }}
      >
        {player.position_name}
      </span>

      {/* Player name */}
      <span className="flex-1 font-medium text-xs truncate">{player.web_name}</span>

      {/* Team */}
      <span className="text-xs text-gray-500">{player.team_name}</span>

      {/* Price */}
      <span className="text-xs text-gray-400 tabular-nums w-12 text-right">
        {formatPrice(player.price)}m
      </span>

      {/* Score */}
      <span className="text-xs tabular-nums w-10 text-right text-green-400">
        {formatDecimal(player.compositeScore)}
      </span>

      {/* Actions (only on editable/right column) */}
      {!readonly && (
        <div className="flex items-center gap-1 ml-1">
          {/* Lock toggle */}
          <button
            onClick={onToggleLock}
            className={`text-sm px-1 ${locked ? "text-yellow-400" : "text-gray-600"}`}
            title={locked ? "Unlock" : "Lock"}
          >
            {locked ? "🔒" : "🔓"}
          </button>
          {/* Remove (only if not locked) */}
          {!locked && (
            <button
              onClick={onRemove}
              className="text-xs text-gray-600 hover:text-red-400 px-1"
              title="Remove"
            >
              ✕
            </button>
          )}
        </div>
      )}
    </div>
  );
}
