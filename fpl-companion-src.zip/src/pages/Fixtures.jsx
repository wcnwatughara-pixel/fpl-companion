/**
 * Fixtures.jsx -- Fixture Difficulty Grid page
 *
 * Shows all 20 teams with their upcoming fixture difficulties
 * colour-coded in a grid. Users can sort by team name or by
 * "easiest upcoming run" to spot which teams have favorable fixtures.
 */

import { useState, useMemo } from "react";
import { useFpl } from "../context/FplContext.jsx";
import FixtureGrid from "../components/FixtureGrid.jsx";
import { buildFdrGrid, sumFdr } from "../utils/fdrCalc.js";
import { FixtureMiniRow } from "../components/FixtureGrid.jsx";

export default function Fixtures() {
  const { players, teamsById, currentGw, loading } = useFpl();
  const [sortBy, setSortBy] = useState("name"); // "name" or "easiest"
  const [expandedTeam, setExpandedTeam] = useState(null);

  // How many GWs to show in the grid
  const GW_COUNT = 6;

  // Build the fixture grid data
  const gridData = useMemo(() => {
    if (!teamsById || Object.keys(teamsById).length === 0 || !currentGw) return [];

    // We need the raw fixtures from localStorage (they were cached by the API layer)
    let fixtures = [];
    try {
      const cached = localStorage.getItem("fpl_fixtures");
      if (cached) {
        fixtures = JSON.parse(cached).data || [];
      }
    } catch {
      return [];
    }

    let grid = buildFdrGrid(fixtures, teamsById, currentGw, GW_COUNT);

    // Sort based on user selection
    if (sortBy === "easiest") {
      grid = [...grid].sort((a, b) => sumFdr(a) - sumFdr(b));
    }

    return grid;
  }, [teamsById, currentGw, sortBy]);

  // Get extended fixtures for the expanded team (all remaining season)
  const expandedFixtures = useMemo(() => {
    if (!expandedTeam || !players.length) return [];

    // Find any player from that team to get their upcoming_fixtures
    const teamPlayer = players.find((p) => p.team === expandedTeam.teamId);
    return teamPlayer?.upcoming_fixtures || [];
  }, [expandedTeam, players]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading fixtures...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">Fixture Difficulty Grid</h1>

        {/* Sort toggle */}
        <div className="flex gap-2">
          <button
            onClick={() => setSortBy("name")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              sortBy === "name"
                ? "bg-[#333] text-white"
                : "bg-[#111] text-gray-400 hover:bg-[#1a1a1a]"
            }`}
          >
            A-Z
          </button>
          <button
            onClick={() => setSortBy("easiest")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              sortBy === "easiest"
                ? "bg-[#333] text-white"
                : "bg-[#111] text-gray-400 hover:bg-[#1a1a1a]"
            }`}
          >
            Easiest Run
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 text-xs text-gray-400">
        <span>Difficulty:</span>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((fdr) => (
            <span
              key={fdr}
              className="px-2 py-0.5 rounded text-[10px] font-medium"
              style={{
                backgroundColor:
                  fdr === 1 ? "#375523" :
                  fdr === 2 ? "#01fc7a" :
                  fdr === 3 ? "#e7e7e7" :
                  fdr === 4 ? "#ff1751" :
                  "#80072d",
                color: fdr === 2 || fdr === 3 ? "#000" : "#fff",
              }}
            >
              {fdr}
            </span>
          ))}
        </div>
        <span className="text-gray-500">1 = easiest, 5 = hardest</span>
      </div>

      {/* The grid */}
      <div className="rounded-lg overflow-hidden" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
        <FixtureGrid
          gridData={gridData}
          startGw={currentGw}
          count={GW_COUNT}
          onTeamClick={(team) =>
            setExpandedTeam(expandedTeam?.teamId === team.teamId ? null : team)
          }
        />
      </div>

      {/* Expanded team view */}
      {expandedTeam && (
        <div className="rounded-lg p-4" style={{ backgroundColor: "#111", border: "1px solid #222" }}>
          <h3 className="text-sm font-semibold mb-3">
            {expandedTeam.teamName} -- All Upcoming Fixtures
          </h3>
          <FixtureMiniRow fixtures={expandedFixtures} />
        </div>
      )}
    </div>
  );
}
